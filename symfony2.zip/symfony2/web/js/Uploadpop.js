$(document).ready(function (e) {
    $("#uploadpopform").on('submit',(function(e) {
		$("#loadingUploadpop").show();
		$("#popuploadFaliure").hide();
		
        e.preventDefault();
			
    var kickimg = $("#Selectpop").val();
    if((kickimg == '') ){
       $("#popuploadFaliure").show();
	   $("#loadingUploadpop").hide();
    }else{
        $.ajax({
            url: "functions/Uploadpop.php",
            type: "POST",
            data:  new FormData(this),
            contentType: false,
            cache: false,
            processData:false,
            success: function(data){
				$("#popuploadFaliure").hide();
				$("#imgselect").hide();
				$("#loadingUploadpop").hide();
                $("#popuploadSuccess").show();
            } 			
       });
	}   
	   
	   
	   
	   
	   
    }));
});