$(document).ready(function (e) {
    $("#AddKicksForm").on('submit',(function(e) {
		$("#loadingAddKicks").show();
		$("#KickAddFailure").hide();
		
        e.preventDefault();
		
	var kickquantity = $("#KickQuantityText").val();	
	var kickprice = $("#KickPriceText").val();	
	var kickdescription = $("#KickDescriptionText").val();		
	var kickname = $("#KickNameText").val();
	    kickname = kickname.replace(/["']{1}/gi,"");	
		document.getElementById("KickNameText").value = kickname;
        kickdescription = kickdescription.replace(/["']{1}/gi,"");
		document.getElementById("KickDescriptionText").value = kickdescription;
    var kickimg = $("#SelectImage").val();
    if((kickimg == '') || (kickname == '') || (kickdescription == '') || isNaN(kickprice) || isNaN(kickquantity) || kickprice < 0|| kickquantity < 0){
       $("#KickAddFailure").show();
	   $("#loadingAddKicks").hide();
    }else{
        $.ajax({
            url: "../admin/AdminFunctions/AddKicks.php",
            type: "POST",
            data:  new FormData(this),
            contentType: false,
            cache: false,
            processData:false,
            success: function(data){
				$("#AddKickContent").hide();
				$("#loadingAddKicks").hide();
                $("#KickAddSuccess").show();
            } 			
       });
	}   
	   
	   
	   
	   
	   
    }));
});