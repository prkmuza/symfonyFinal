  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');  ga('create', 'UA-89796118-1', 'auto');  ga('send', 'pageview');    function ViewAddToCart(x){	$("#AddtoCart").show(1000);	$("#CartDetail"+x).hide(1000); 	$("#CartDetail"+x+"Added").show(1000);	$("#CartDetail"+x+"AddAgain").show(1000);	    var xhttp1 = new XMLHttpRequest();  xhttp1.onreadystatechange = function() {    if (xhttp1.readyState == 4 && xhttp1.status == 200) {     document.getElementById("ViewAddtoCart").innerHTML = xhttp1.responseText;    }  };  xhttp1.open("GET", "functions/ViewAddToCart.php?kickid="+x, true);  xhttp1.send(); }function CloseAddtoCart(x){	$("#AddtoCart").hide(1000); 	$("#CartDetail"+x).show(1000);	$("#CartDetail"+x+"Added").hide(1000); 	$("#CartDetail"+x+"AddAgain").hide(1000); }     function LoadSignin(){		   $("#KGSZSignup").hide(1000);  		   $("#KGSZSignin").show(1000);   }        function CloseKGSZSignin() {	$("#KGSZSignin").hide(1000);  }    function ShowFrgtPswrd(){		   $("#KGSZSignup").hide(1000); 		   $("#KGSZSignin").hide(1000); 		   $("#ForgotPsw").show(1000);   }        function CloseFrgPswrd(){		   $("#ForgotPsw").hide(1000);    }      function ConfirmEmailFrgPswrd(){	   	   var PasswrdEmail = document.getElementById("EmailForgotPassword").value;	   		var xhttpFRGT = new XMLHttpRequest();  xhttpFRGT.onreadystatechange = function() {    if (xhttpFRGT.readyState == 4 && xhttpFRGT.status == 200) {  document.getElementById("ForgotPswContent").innerHTML = xhttpFRGT.responseText;    }  };  xhttpFRGT.open("GET", "functions/ConfirmForgotPassword.php?frgtpswrdmail="+PasswrdEmail, true);  xhttpFRGT.send();   }            function LoadSignup(){		   $("#KGSZSignup").show(1000);		   $("#KGSZSignin").hide(1000);    }        function CloseKGSZSignup() {	$("#KGSZSignup").hide(1000);   }     function SaveDeliveryDelails() {    var PhoneNumber = document.getElementById("PhoneNumber").value;    var Address = document.getElementById("Address").value;	var City = document.getElementById("City").value;   	if((Address == '') || (City == '') || isNaN(PhoneNumber) || (PhoneNumber.toString().length) < 9){       $("#DeliveryDetailFailure").show(1000);    }else{				var xhttp10 = new XMLHttpRequest();  xhttp10.onreadystatechange = function() {    if (xhttp10.readyState == 4 && xhttp10.status == 200) {     location.replace("https://www.stakeey.com/ac.php?c="+Math.random());    }  };  xhttp10.open("GET", "functions/SaveDeliveryDelails.php?&pn="+PhoneNumber+"&a="+Address+"&c="+City, true);  xhttp10.send();			}	  }    function NotNowDeliveryDelails(){         location.replace("https://www.stakeey.com/ac.php?c="+Math.random());	  }    function Search() {		var s = document.getElementById("SearchText").value;	 if (s == ""){	 $("#CloseSearch").hide(1000); 	 if($("#SlideShow").length > 0)	 {	 $("#SlideShow").show(1000);     }  var xhttp5 = new XMLHttpRequest();  xhttp5.onreadystatechange = function() {    if (xhttp5.readyState == 4 && xhttp5.status == 200) {     document.getElementById("KickContent").innerHTML = xhttp5.responseText;    }  };  xhttp5.open("GET", "functions/CloseSearch.php", true);  xhttp5.send();	 }else{	 $("#CloseSearch").show(1000);	 $("#SlideShow").hide(1000); 	 	 var xhttp4 = new XMLHttpRequest();  xhttp4.onreadystatechange = function() {    if (xhttp4.readyState == 4 && xhttp4.status == 200) {     document.getElementById("KickContent").innerHTML = xhttp4.responseText;    }  };  xhttp4.open("GET", "functions/Search.php?s="+s, true);  xhttp4.send(); }	}function CloseSearch() {	document.getElementById("SearchText").value = "";	$("#CloseSearch").hide(1000); 	    if($("#SlideShow").length > 0)	 {	$("#SlideShow").show(1000);	 }		var xhttp6 = new XMLHttpRequest();  xhttp6.onreadystatechange = function() {    if (xhttp6.readyState == 4 && xhttp6.status == 200) {     document.getElementById("KickContent").innerHTML = xhttp6.responseText;    }  };  xhttp6.open("GET", "functions/CloseSearch.php", true);  xhttp6.send();	}     function SortBy(){		var x = document.getElementById("SortBy").value;		$("#LoadSort").show(1000);		var xhttpSortBy = new XMLHttpRequest();  xhttpSortBy.onreadystatechange = function() {    if (xhttpSortBy.readyState == 4 && xhttpSortBy.status == 200) {     document.getElementById("KickContent").innerHTML = xhttpSortBy.responseText;    }  };  xhttpSortBy.open("GET", "functions/SortBy.php?sv="+x, true);  xhttpSortBy.send();				   	      }   function ValidateQuantity(x){		var kickquantity = document.getElementById("KickQuantity").value;	    var xhttp3 = new XMLHttpRequest();  xhttp3.onreadystatechange = function() {    if (xhttp3.readyState == 4 && xhttp3.status == 200) {     document.getElementById("ValidateQuantity").innerHTML = xhttp3.responseText;    }  };  xhttp3.open("GET", "functions/ValidateQuantity.php?kickid="+x+"&kickquantity="+kickquantity, true);  xhttp3.send(); }     function elementInViewport2(el) {  var top = el.offsetTop;  var left = el.offsetLeft;  var width = el.offsetWidth;  var height = el.offsetHeight;  while(el.offsetParent) {    el = el.offsetParent;    top += el.offsetTop;    left += el.offsetLeft;  }  return (    top < (window.pageYOffset + window.innerHeight) &&    left < (window.pageXOffset + window.innerWidth) &&    (top + height) > window.pageYOffset &&    (left + width) > window.pageXOffset  );} function UpdateHead(){    if (elementInViewport2(document.getElementById('KickBodyLabel'))){			$("#MainLogo").show(1000);		$("#KickMainLabel").hide(1000); 	}else{		$("#MainLogo").hide(1000); 		$("#KickMainLabel").show(1000);	}     };  function ViewCategories(x){	$("#CategoryMain").show(1000);		var xhttp8 = new XMLHttpRequest();  xhttp8.onreadystatechange = function() {    if (xhttp8.readyState == 4 && xhttp8.status == 200) {     document.getElementById("ViewCategory").innerHTML = xhttp8.responseText;    }  };  xhttp8.open("GET", "functions/ViewCategory.php?type="+x, true);  xhttp8.send(); }function SelectCategoryItem(x,y){	$("#CategoryMain").show(1000);	$("#CategoryLoad").show(1000);		var xhttp9 = new XMLHttpRequest();  xhttp9.onreadystatechange = function() {    if (xhttp9.readyState == 4 && xhttp9.status == 200) {     document.getElementById("ViewCategory").innerHTML = xhttp9.responseText;    }  };  xhttp9.open("GET", "functions/ViewCategoryItem.php?category="+x+"&type="+y, true);  xhttp9.send(); }function CloseCategories(x){	$("#CategoryMain").hide(1000); }function LoadViewCategory(){	$("#CategoryLoad").show(1000); }function KGSZViewP(x){	document.getElementById("KGSZViewP"+x).style.display = "block";}function KGSZCloseViewP(x){	document.getElementById("KGSZViewP"+x).style.display = "none";}
  
         function ShowMoreKicks(x,y){
		   
		   $("#LoadKicks").show(1000);
		   
		   var xhttp7 = new XMLHttpRequest();
        xhttp7.onreadystatechange = function() {
        if (xhttp7.readyState == 4 && xhttp7.status == 200) {
       document.getElementById("MoreKickContent"+y).innerHTML = xhttp7.responseText;
      }
     };
    xhttp7.open("GET", "functions/ShowMoreKicks.php?c="+Math.random()+"&kickNum="+x+"&kickContent="+y, true);
    xhttp7.send(); 
	
        
   }
   
   function ShowMoreWatches(x,y){
		   
		   $("#LoadWatches").show(1000);
		   
		   var xhttp11 = new XMLHttpRequest();
        xhttp11.onreadystatechange = function() {
        if (xhttp11.readyState == 4 && xhttp11.status == 200) {
       document.getElementById("MoreWatchContent"+y).innerHTML = xhttp11.responseText;
      }
     };
    xhttp11.open("GET", "functions/ShowMoreWatches.php?c="+Math.random()+"&kickNum="+x+"&kickContent="+y, true);
    xhttp11.send(); 
	
        
   }
   
      function ShowMoreCaps(x,y){
		   
		   $("#LoadCaps").show(1000);
		   
		   var LoadCaps = new XMLHttpRequest();
        LoadCaps.onreadystatechange = function() {
        if (LoadCaps.readyState == 4 && LoadCaps.status == 200) {
       document.getElementById("MoreCapContent"+y).innerHTML = LoadCaps.responseText;
      }
     };
    LoadCaps.open("GET", "functions/ShowMoreCaps.php?c="+Math.random()+"&kickNum="+x+"&kickContent="+y, true);
    LoadCaps.send(); 
	     
   }