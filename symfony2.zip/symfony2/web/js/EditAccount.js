$(document).ready(function (e) {
    $("#EditProfileForm").on('submit',(function(e) {
		$("#loadingAccEdit").show();
		$("#AccountEditFailure").hide();
		
        e.preventDefault();
		
		
	var CacheFix = Math.random();	
	var UserID = document.getElementById("UserID").value;	
	var Name = document.getElementById("NameEdit").value;	
	var PhoneNumber = document.getElementById("PhoneNumberEdit").value;
    var Address = document.getElementById("AddressEdit").value;
	var City = document.getElementById("CityEdit").value;
	var PayPalAccountEmail = document.getElementById("PayPalAccountEmail").value;
	var BankingBankName = document.getElementById("BankingBankName").value;
	var BankingAccountNumber = document.getElementById("BankingAccountNumber").value;
	var BankingAccountName = document.getElementById("BankingAccountName").value;
	var BankingBranch = document.getElementById("BankingBranch").value;
	var BankingCountry = document.getElementById("BankingCountry").value;
	var IntentToAddProduct = document.getElementById("IntentToAddProduct").value;
   
	if((Address == '') || (Name == '') || (City == '') || isNaN(PhoneNumber) || (PhoneNumber.toString().length) < 9){
       document.getElementById("AccountEditFailure").style.display = "block";
	   $("#loadingAccEdit").hide();
    }else if(($('#PPadded').is(":visible")) || ($('#ETFadded').is(":visible"))){
		
		if(($('#PPadded').is(":visible"))&& (PayPalAccountEmail == ''))
		{
			document.getElementById("AccountEditFailure").style.display = "block";
			document.getElementById("AccountEditFailureInfo").innerHTML = 'You added PayPal as a payment option, please verify your paypal account so we can save your details...';
			
		}else if(($('#ETFadded').is(":visible"))&&(BankingBankName =='')||(($('#ETFadded').is(":visible"))&&(BankingAccountNumber =='')&&(BankingCountry ==''))){
		
               document.getElementById("AccountEditFailure").style.display = "block";
			document.getElementById("AccountEditFailureInfo").innerHTML = 'You added ETF and Cash Deposits as a payment option, please make sure all banking details are filled in...';
		
	}else{
		
				var BankingDetailsList = '';
			$((".BankingDetails")).each(function() {
		
		 var BankingDetailName = $(this).val();
		 //lets remove characters we dont want mainly ',' so in php theres no problem when creating an array
		BankingDetailName = BankingDetailName.replace(',','');
         BankingDetailsList= BankingDetailsList+BankingDetailName+',';//save in csv form
    });
	document.getElementById("BankingDetailsList").value= BankingDetailsList;
		
		        $.ajax({
            url: "functions/EditAccount.php",
            type: "POST",
            data:  new FormData(this),
            contentType: false,
            cache: false,
            processData:false,
            success: function(data){
				
				if(IntentToAddProduct == 'IntentShown')
				{
					location.replace("https://www.stakeey.com/newproduct.php?SAccid="+UserID+"&c="+CacheFix+"&type=general");
				}else{
				location.replace("https://www.stakeey.com/ac.php?c="+CacheFix+"&id="+UserID);
				}
            } 			
       });
		
	} 
		

	}else{
		var BankingDetailsList = '';
			$((".BankingDetails")).each(function() {
		
		 var BankingDetailName = $(this).val();
		 //lets remove characters we dont want mainly ',' so in php theres no problem when creating an array
		BankingDetailName = BankingDetailName.replace(',','');
         BankingDetailsList= BankingDetailsList+BankingDetailName+',';//save in csv form
    });
	document.getElementById("BankingDetailsList").value= BankingDetailsList;
		
		        $.ajax({
            url: "functions/EditAccount.php",
            type: "POST",
            data:  new FormData(this),
            contentType: false,
            cache: false,
            processData:false,
            success: function(data){
				
				if(IntentToAddProduct == 'IntentShown')
				{
					location.replace("https://www.stakeey.com/newproduct.php?SAccid="+UserID+"&c="+CacheFix+"&type=general");
				}else{
				location.replace("https://www.stakeey.com/ac.php?c="+CacheFix+"&id="+UserID);
				}
				
            } 			
       });
		
	}   
	   
  
    }));
});