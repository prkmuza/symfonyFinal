// JavaScript Document to run the login of users...
$(document).ready(function(e) {
//	alert("Clicked");

	var working = false;
	var CacheFix = Math.random();
	//use JQuery to submit the login form....
	$("#SigninForm").submit(function(e) {
	$("#loadingSignin").show();
		//prevent the default submitting 
		e.preventDefault();
		
		if (working) return false;
		working = true;
		$('.error').remove();
		
		//send it up for validation in the validationLogin file..
        $.post('functions/LoadSignin.php', $(this).serialize(), function(msg) {
			
			working = false;
			if (msg.status) {
				
				//if it has worked, then redirect the person back to the place they were..
				location.replace("https://www.stakeey.com/ac.php?c="+CacheFix);
			
			//else if there are any errors, then put each one of them in their respective labels..
			} else {
			 
				$.each(msg.errors, function(k, v) {
                    $("#loadingSignin").hide();
					$('label[for="'+k+'"]').append(v);
					 
				})
			}
		}, 'json');
    });
	
	
	
	
});