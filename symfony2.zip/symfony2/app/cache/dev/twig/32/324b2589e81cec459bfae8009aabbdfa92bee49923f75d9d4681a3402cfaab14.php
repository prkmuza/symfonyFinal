<?php

/* ::base.html.twig */
class __TwigTemplate_1b6fe78e035f9a5a3841c53905012ddb1c101627b1dac4da3a114cc5a09bcf68 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
<head> 
    <meta charset=\"utf-8\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0,user-scalable=0\">
\t<meta name=\"keywords\" content=\"SocialPlacesApp, online store,online shopping,free delivery,food,mazowe,beverage,community,Zimbabwe,Africa,Cape Town, South Africa\">
\t<meta name=\"description\" content=\"SocialPlacesApp online store\">
\t<meta property=\"og:locale\" content=\"en_US\" />
\t<meta property=\"og:title\" content=\"SocialPlacesApp online store\"/>
    <meta property=\"og:type\" content=\"website\"/>
    <meta property=\"og:url\" content=\"https://www.SocialPlacesApp.co.za\"/>
    <meta property=\"og:image\" content=\"https://www.SocialPlacesApp.co.za/SiteImages/ZELogo.png\"/>
    <meta property=\"og:site_name\" content=\"SocialPlacesApp\"/>
    <meta property=\"og:description\" content=\"SocialPlacesApp online store.\"/>
    <meta name=\"apple-mobile-web-app-capable\" content=\"yes\">
    <meta name=\"apple-mobile-web-app-status-bar-style\" content=\"black\">
    <link rel=\"shortcut icon\" href=\"SiteImages/ZELogo.png\"/>
    <link rel=\"stylesheet\" type=\"text/css\" href=\"css/MainstyleMobile.css\"/>
\t<script src='https://www.google.com/recaptcha/api.js'></script>
    <title>SocialPlacesApp</title>
\t\t<script src=\"js/responsive-nav.js\"></script>
</head>

<body id=\"TheBody\" bgcolor=\"#e2e1e0\" >


     <header>
\t 
      <a  class=\"logo\" data-scroll>
 <div id=\"MainLogo\"></div>
 <div><h2 id=\"KickMainLabel\" style=\"color:#000000;\">
SocialPlacesApp
 </h2></div>
 </a>
 
      <nav class=\"nav-collapse\">
        <ul>

\t\t\t
\t\t 
        </ul>
      </nav>
    </header>
\t<br><br><br>

<br>\t
\t<div style=\"max-width:380px;min-height:380px;margin:0 auto;border-radius:5px;background-color:#ffffff;\">
\t
\t
\t<div style=\"width:260px;margin:0 auto;text-align:center;\">
\t";
        // line 51
        $this->displayBlock('body', $context, $blocks);
        // line 52
        echo "
\t
\t</div>
\t
\t</div>

<script src=\"js/jquery.min.js\"></script>
<script src=\"js/jquery-1.4.2.min.js\"></script>
\t<script src=\"js/1.4.4 jquery.js\"></script>
\t<script src=\"js/1.12.2  jquery.js\"></script>
<script src=\"js/fastclick.js\"></script>
    <script src=\"js/scroll.js\"></script>
    <script src=\"js/fixed-responsive-nav.js\"></script>\t

\t
   </body>
</html>

\t<script>
\t
\tfunction SendContact(){
\t\t
\tvar name = \$('#Name').val(); //Validierung der Form-Daten
    var cellnum = \$('#CellNum').val();
    var email = \$('#Email').val();
\t
\tif(name == \"\" || cellnum == \"\" || email == \"\" || grecaptcha.getResponse() == \"\")
\t{
\t\talert('please fill in all the details above and confirm you are not a robot');
\t}else{
\t\t
\t\tvar xhttp2 = new XMLHttpRequest();
     xhttp2.onreadystatechange = function() {
     if (xhttp2.readyState == 4 && xhttp2.status == 200) {
     document.getElementById(\"contactResponse\").innerHTML = xhttp2.responseText;
\t 
\t var str = xhttp2.responseText;
     if(str.includes(\"Thanks\"))
\t {
\t\t document.getElementById(\"showdetail\").style.display = \"none\";
\t }
\t 
     }
     };
     xhttp2.open(\"GET\", \"contact.php?name=\"+name+\"&cellnum=\"+cellnum+\"&email=\"+email, true);
    xhttp2.send(); 
\t}


\t
\t
\t//
\t}
\t
\t</script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 51
    public function block_body($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        echo " ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  140 => 51,  77 => 52,  75 => 51,  23 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
<head> 
    <meta charset=\"utf-8\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0,user-scalable=0\">
\t<meta name=\"keywords\" content=\"SocialPlacesApp, online store,online shopping,free delivery,food,mazowe,beverage,community,Zimbabwe,Africa,Cape Town, South Africa\">
\t<meta name=\"description\" content=\"SocialPlacesApp online store\">
\t<meta property=\"og:locale\" content=\"en_US\" />
\t<meta property=\"og:title\" content=\"SocialPlacesApp online store\"/>
    <meta property=\"og:type\" content=\"website\"/>
    <meta property=\"og:url\" content=\"https://www.SocialPlacesApp.co.za\"/>
    <meta property=\"og:image\" content=\"https://www.SocialPlacesApp.co.za/SiteImages/ZELogo.png\"/>
    <meta property=\"og:site_name\" content=\"SocialPlacesApp\"/>
    <meta property=\"og:description\" content=\"SocialPlacesApp online store.\"/>
    <meta name=\"apple-mobile-web-app-capable\" content=\"yes\">
    <meta name=\"apple-mobile-web-app-status-bar-style\" content=\"black\">
    <link rel=\"shortcut icon\" href=\"SiteImages/ZELogo.png\"/>
    <link rel=\"stylesheet\" type=\"text/css\" href=\"css/MainstyleMobile.css\"/>
\t<script src='https://www.google.com/recaptcha/api.js'></script>
    <title>SocialPlacesApp</title>
\t\t<script src=\"js/responsive-nav.js\"></script>
</head>

<body id=\"TheBody\" bgcolor=\"#e2e1e0\" >


     <header>
\t 
      <a  class=\"logo\" data-scroll>
 <div id=\"MainLogo\"></div>
 <div><h2 id=\"KickMainLabel\" style=\"color:#000000;\">
SocialPlacesApp
 </h2></div>
 </a>
 
      <nav class=\"nav-collapse\">
        <ul>

\t\t\t
\t\t 
        </ul>
      </nav>
    </header>
\t<br><br><br>

<br>\t
\t<div style=\"max-width:380px;min-height:380px;margin:0 auto;border-radius:5px;background-color:#ffffff;\">
\t
\t
\t<div style=\"width:260px;margin:0 auto;text-align:center;\">
\t{% block body %} {% endblock %}

\t
\t</div>
\t
\t</div>

<script src=\"js/jquery.min.js\"></script>
<script src=\"js/jquery-1.4.2.min.js\"></script>
\t<script src=\"js/1.4.4 jquery.js\"></script>
\t<script src=\"js/1.12.2  jquery.js\"></script>
<script src=\"js/fastclick.js\"></script>
    <script src=\"js/scroll.js\"></script>
    <script src=\"js/fixed-responsive-nav.js\"></script>\t

\t
   </body>
</html>

\t<script>
\t
\tfunction SendContact(){
\t\t
\tvar name = \$('#Name').val(); //Validierung der Form-Daten
    var cellnum = \$('#CellNum').val();
    var email = \$('#Email').val();
\t
\tif(name == \"\" || cellnum == \"\" || email == \"\" || grecaptcha.getResponse() == \"\")
\t{
\t\talert('please fill in all the details above and confirm you are not a robot');
\t}else{
\t\t
\t\tvar xhttp2 = new XMLHttpRequest();
     xhttp2.onreadystatechange = function() {
     if (xhttp2.readyState == 4 && xhttp2.status == 200) {
     document.getElementById(\"contactResponse\").innerHTML = xhttp2.responseText;
\t 
\t var str = xhttp2.responseText;
     if(str.includes(\"Thanks\"))
\t {
\t\t document.getElementById(\"showdetail\").style.display = \"none\";
\t }
\t 
     }
     };
     xhttp2.open(\"GET\", \"contact.php?name=\"+name+\"&cellnum=\"+cellnum+\"&email=\"+email, true);
    xhttp2.send(); 
\t}


\t
\t
\t//
\t}
\t
\t</script>

", "::base.html.twig", "C:\\Program Files (x86)\\Ampps\\www\\symfony2\\app/Resources\\views/base.html.twig");
    }
}
