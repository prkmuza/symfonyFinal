<?php

/* PanashesBundlePanashesBundle:Default:indxxxxxex.html.twig */
class __TwigTemplate_19d75a308d5609711fdece59c8702e4ccb690e2e2c6c7431aa15249731dd6840 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "Hello World!
ssssssss";
    }

    public function getTemplateName()
    {
        return "PanashesBundlePanashesBundle:Default:indxxxxxex.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "PanashesBundlePanashesBundle:Default:indxxxxxex.html.twig", "C:\\Program Files (x86)\\Ampps\\www\\symfony2\\src\\PanashesBundle\\PanashesBundle/Resources/views/Default/indxxxxxex.html.twig");
    }
}
