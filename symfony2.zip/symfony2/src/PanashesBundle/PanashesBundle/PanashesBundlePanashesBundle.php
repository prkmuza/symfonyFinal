<?php

namespace PanashesBundle\PanashesBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PanashesBundlePanashesBundle extends Bundle
{
}
