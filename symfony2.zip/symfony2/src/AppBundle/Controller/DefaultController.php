<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use PanashesBundle\PanashesBundle\Entity\contactlist; //to reference a class on another page, namespace and classname combo

class DefaultController extends Controller
{
   	 /**
     * @Route("/SaveContact/SrtName/{StrName}/StrCellNumber/{StrCellNumber}/StrEmail/{StrEmail}", name="SaveContact")
     */
    public function SaveContactAction(Request $request,$StrName,$StrCellNumber,$StrEmail)
    {
		$strdate = date("Y-m-d");
		//get contact list class to help save contents to DB
		$user = new contactlist();
		
		$user->setName($StrName);
		$user->setCellnumber($StrCellNumber);
		$user->setEmail($StrEmail);
		$user->setDate($strdate);
		
		$em = $this->getDoctrine()->getManager();
		$em->persist($user);
		$em->flush();
		
		//message for user submitting
        $message = \Swift_Message::newInstance()
                  ->setSubject('Thanks for contacting us')
              	  ->setFrom('russmuza@gmail.com')
                  ->setTo($StrEmail)
				  ->setCharset('utf-8')
				  ->setContentType('text/html')
                  ->setBody('Hi,'. $StrName. ' we will call you as soon as possible on your number:'.$StrCellNumber );

         $this->get('mailer')->send($message);		
//message for admin
$message = \Swift_Message::newInstance()
                  ->setSubject('Admin alert')
              	  ->setFrom('russmuza@gmail.com')
                  ->setTo('panamuza@yahoo.com')
				  ->setCharset('utf-8')
				  ->setContentType('text/html')
                  ->setBody("Hi Admin, ".$StrName." wants you to call them on ". $StrCellNumber. " thanks");

         $this->get('mailer')->send($message);			 
		
		
		
		$data['new'] = 'Thanks';
		return new JsonResponse($data);

		
    
    }
}
